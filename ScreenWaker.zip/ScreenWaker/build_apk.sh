#!/usr/bin/env bash
# ============================================================
# ScreenWaker - Automated APK Build Script
# Run this once on any Linux/macOS machine with Java 17+ installed
# Output: app/build/outputs/apk/debug/app-debug.apk
# ============================================================

set -e

echo "==> [1/4] Checking Java..."
java -version || { echo "ERROR: Java not found. Install JDK 17."; exit 1; }

echo "==> [2/4] Setting up Gradle Wrapper..."
if [ ! -f "gradlew" ]; then
    # Download gradle wrapper jar if missing
    mkdir -p gradle/wrapper
    curl -Lo gradle/wrapper/gradle-wrapper.jar \
        "https://github.com/gradle/gradle/raw/v8.4.0/gradle/wrapper/gradle-wrapper.jar"
    
    cat > gradlew << 'GRADLEW'
#!/usr/bin/env sh
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
exec java -jar "$SCRIPT_DIR/gradle/wrapper/gradle-wrapper.jar" "$@"
GRADLEW
    chmod +x gradlew
fi

echo "==> [3/4] Running Gradle assembleDebug..."
chmod +x gradlew
./gradlew assembleDebug --stacktrace

echo ""
echo "==> [4/4] BUILD COMPLETE"
echo "    APK location: app/build/outputs/apk/debug/app-debug.apk"
APK="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
    ls -lh "$APK"
    echo ""
    echo "    Transfer to device and install with:"
    echo "    adb install $APK"
else
    echo "    APK not found — check build output above for errors."
fi
