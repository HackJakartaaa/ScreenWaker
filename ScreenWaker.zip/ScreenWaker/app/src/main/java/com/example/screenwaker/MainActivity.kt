package com.example.screenwaker

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var btnGrantPermission: Button
    private lateinit var tvStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnGrantPermission = findViewById(R.id.btnGrantPermission)
        tvStatus = findViewById(R.id.tvStatus)

        btnGrantPermission.setOnClickListener {
            val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
    }

    private fun updatePermissionStatus() {
        if (isNotificationListenerEnabled()) {
            tvStatus.text = "Status: Notification Access GRANTED. App is active."
            tvStatus.setTextColor(resources.getColor(android.R.color.holo_green_dark, theme))
            btnGrantPermission.text = "Manage Notification Access"
        } else {
            tvStatus.text = "Status: Permission NOT granted. Tap the button above."
            tvStatus.setTextColor(resources.getColor(android.R.color.holo_red_dark, theme))
            btnGrantPermission.text = "Grant Notification Access"
        }
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val packageName = packageName
        val flat = Settings.Secure.getString(
            contentResolver,
            "enabled_notification_listeners"
        )
        if (!TextUtils.isEmpty(flat)) {
            val names = flat.split(":").toTypedArray()
            for (name in names) {
                val componentName = ComponentName.unflattenFromString(name)
                if (componentName != null && TextUtils.equals(packageName, componentName.packageName)) {
                    return true
                }
            }
        }
        return false
    }
}
