package com.example.screenwaker

import android.content.Context
import android.os.PowerManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class MyNotificationListener : NotificationListenerService() {

    private val whitelistedPackages = setOf(
        "com.whatsapp",
        "com.whatsapp.w4b",
        "org.telegram.messenger",
        "org.telegram.messenger.web"
    )

    private val wakeTag = "ScreenWaker:NotificationWakeLock"
    private val wakeDurationMs = 5000L

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        super.onNotificationPosted(sbn)

        val packageName = sbn.packageName ?: return

        if (!whitelistedPackages.contains(packageName)) return

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager

        if (powerManager.isInteractive) return

        @Suppress("DEPRECATION")
        val wakeLock = powerManager.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            wakeTag
        )

        try {
            wakeLock.acquire(wakeDurationMs)
        } finally {
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                try {
                    if (wakeLock.isHeld) {
                        wakeLock.release()
                    }
                } catch (e: RuntimeException) {
                    // WakeLock already released, safe to ignore
                }
            }, wakeDurationMs)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        // Not needed for this use case
    }
}
