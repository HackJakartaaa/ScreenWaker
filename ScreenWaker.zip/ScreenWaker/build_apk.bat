@echo off
REM ============================================================
REM ScreenWaker - Automated APK Build Script (Windows)
REM Requires: JDK 17+ installed and JAVA_HOME set
REM Output: app\build\outputs\apk\debug\app-debug.apk
REM ============================================================

echo [1/3] Checking Java...
java -version
if errorlevel 1 (
    echo ERROR: Java not found. Install JDK 17 and set JAVA_HOME.
    pause
    exit /b 1
)

echo [2/3] Running Gradle assembleDebug...
call gradlew.bat assembleDebug --stacktrace
if errorlevel 1 (
    echo BUILD FAILED. Check output above.
    pause
    exit /b 1
)

echo [3/3] BUILD COMPLETE
echo APK: app\build\outputs\apk\debug\app-debug.apk
pause
